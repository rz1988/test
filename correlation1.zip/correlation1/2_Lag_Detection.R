# This code builds a ARIMA-X model for S1 

# Split the data to three parts

training <- processed_data[1:40, ]
validation <- processed_data[41:50, ]
test <- processed_data[51:100, ]

# Detect any AR or MA lags in S1 
# Consider add lag 1 of S1 - Positive previous return means a likely negative return today  

par(mfrow = c(1, 1))
acf(training[, 1], lag.max = NULL, type = c('correlation', 'covariance', 'partial'), plot = T, demean = T, main = 'ACF - S1')
pacf(training[, 1], lag.max = NULL, plot = T, main = 'PACF - S1')



# Detect any correlation with the lags and PC1 and PC2 
# There is a lag correlation between PC1 and S1 
# This can be caused and/or modeled thru the lags of PC1 or S1 

ccf(training[, 1], training[, 2], lag.max = NULL, type = c("correlation", "covariance"), plot = T)
ccf(training[, 1], training[, 3], lag.max = NULL, type = c("correlation", "covariance"), plot = T)

# Detect if any lag of PC1 should be included 
# consider add lag 1 and lag 5 of PC1
acf(proccessed_data[, 2], lag.max = NULL, type = c('correlation', 'covariance', 'partial'), plot = T, demean = T, main = 'ACF - PC1')
pacf(proccessed_data[, 2], lag.max = NULL, plot = T, main = 'PACF - PC1')

# Detect if any lag of PC2 should be included 
# No lag is detected 
acf(proccessed_data[, 3], lag.max = NULL, type = c('correlation', 'covariance', 'partial'), plot = T, demean = T, main = 'ACF - PC2')
pacf(proccessed_data[, 3], lag.max = NULL, plot = T, main = 'PACF - PC2')







