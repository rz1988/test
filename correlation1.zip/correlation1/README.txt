To run the model follow these steps. 

Assum you save the data in ../data/. 

1_Input_Transform reads in the data and removes the correlation among S2 to S10.
2_Lag_Detection looks at any potential lags presented in individual series.
3_model explores a suit of candidate models and selects the best model based on out-of-sample performance.

@Author Zhi Ruan May 2016 