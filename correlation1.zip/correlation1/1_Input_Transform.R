# This code processes the raw data 

library(gdata)
library(plotly)

data <- read.xls("data/correlation1.xlsx")

# look at the correlation among inputs
cor(data[1:50, 2:11])
plot_ly(z = cor(data[1:50, 2:11]), type = 'heatmap')

# all inputs are highly correlated 
# apply PCA to remove correlation among S2 - S10 

pca <- prcomp(data[, 3:11])
plot(pca$sdev)

## First three PCs will have enough information based the standard deviation 

transformed_input <- as.matrix(data[, 3:11]) %*%  pca$rotation
processed_data <- cbind(data[,2], transformed_input)
cor(processed_data[1:50, ])


# plot the transformed data vor visual inspection 
# Stock returns are stationary 

attach(mtcars)
par(mfrow = c(2, 2))
for(i in 1:10) {
  plot(processed_data[, i], main = paste('Stock price of S', i))
  
}
