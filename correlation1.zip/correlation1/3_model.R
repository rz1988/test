# Build an ARIMA-x Model 
library(forecast)

S1 <- training[, 1]
PC1 <- training[, 2]
PC2 <- training[, 3]
PC3 <- training[, 4]
PC4 <- training[, 5]
PC5 <- training[, 6]
PC6 <- training[, 7]
PC1_lag <- c(0, PC1[1:(length(PC1) - 1)])
PC1_lag_5 <- c(0, 0, 0, 0, 0, PC1[1:(length(PC1) - 5)])


mod1 <- Arima(S1, order = c(0, 0, 0), xreg = cbind(PC1, PC1_lag, PC1_lag_5))
mod1
# AIC 25.19

mod2 <- Arima(S1, order = c(1, 0, 0), xreg = cbind(PC1, PC1_lag, PC1_lag_5))
mod2
# AIC 21.16

mod3<- Arima(S1, order = c(1, 0, 0), xreg = cbind(PC1, PC2)) # *************
mod3
# AIC 16.97 AICC 18.7

mod4 <- Arima(S1, order = c(1, 0, 0), xreg = cbind(PC1, PC2, PC3)) # ************
mod4
# AIC 16.68 AICC 19.23

mod5 <- Arima(S1, order = c(1, 0, 0), xreg = cbind(PC1))
mod5
# AIC 17.35

mod6 <- Arima(S1, order = c(1, 0, 0), xreg = cbind(PC1, PC2, PC3, PC5)) # **********
mod6
# AIC 16.91

mod7 <- Arima(S1, order = c(1, 0, 1), xreg = cbind(PC1)) # ***********
mod7
# AIC 9.86

# Test the model on validation dataset 
mad_error <- function(x, pred) {
  return (mean(abs(pred - x)))
}



pred_mod3 <- predict(mod3, newxreg = validation[, 2:3], n.ahead = 10, se.fit = F)
pred_mod4 <- predict(mod4, newxreg = validation[, 2:4], n.ahead = 10, se.fit = F)
pred_mod5 <- predict(mod5, newxreg = validation[, 2], n.ahead = 10, se.fit = F)
pred_mod6 <- predict(mod6, newxreg = validation[, c(2, 3, 4, 6)], n.ahead = 10, se.fit = F)
pred_mod7 <- predict(mod7, newxreg = validation[, 2], n.ahead = 10, se.fit = F)


mad_error(validation[, 1], pred_mod3)
mad_error(validation[, 1], pred_mod4)
mad_error(validation[, 1], pred_mod5) 
mad_error(validation[, 1], pred_mod6)
mad_error(validation[, 1], pred_mod7)


plot(validation[, 1], pred_mod3)
plot(validation[, 1], pred_mod4)
plot(validation[, 1], pred_mod5)
plot(validation[, 1], pred_mod6)
plot(validation[, 1], pred_mod7)

# use model 5 based on validation result and model complexity 

model_final <- Arima(processed_data[1:50, 1], order = c(1, 0, 0), xreg = processed_data[1:50, 2])


# back-test the model 
# in sample
plot(S1, fitted(mod5)) 
fit <- fitted(mod5) 
sum(S1 * fit > 0) / length(S1)
# out of sample 
sum(validation[, 1] * pred_mod5 > 0) / 10


# Output Model Results 
pred_final <- predict(model_final, newxreg = test[, 2], n.ahead = 50, se.fit = F)
dates <- data[51:100, 1]
out <- data.frame(dates, pred_final)
colnames(out) <- c('Date', 'Value')
write.csv(out, file = 'predictions.csv', row.names = F)

